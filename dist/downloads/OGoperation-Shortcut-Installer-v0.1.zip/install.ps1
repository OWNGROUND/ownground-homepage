[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Url
)

$ErrorActionPreference = 'Stop'

$operationUri = $null
if (-not [Uri]::TryCreate($Url, [UriKind]::Absolute, [ref]$operationUri) -or
    $operationUri.Scheme -ne 'https' -or
    $operationUri.IsLoopback -or
    $operationUri.AbsolutePath -ne '/' -or
    $operationUri.Query -or
    $operationUri.Fragment) {
    throw 'Url must be a root HTTPS address, for example https://customer.ownground.kr/'
}

$sourceIcon = Join-Path $PSScriptRoot 'ogoperation.ico'
if (-not (Test-Path -LiteralPath $sourceIcon -PathType Leaf)) {
    throw "Official Green Ring icon not found: $sourceIcon"
}

$installDirectory = Join-Path $env:LOCALAPPDATA 'OWNGROUND\OGoperation'
$installedIcon = Join-Path $installDirectory 'ogoperation.ico'
$desktopDirectory = [Environment]::GetFolderPath('Desktop')
$desktopShortcut = Join-Path $desktopDirectory 'OGoperation.lnk'
$startMenuDirectory = Join-Path ([Environment]::GetFolderPath('Programs')) 'OWNGROUND'
$startMenuShortcut = Join-Path $startMenuDirectory 'OGoperation.lnk'

New-Item -ItemType Directory -Path $installDirectory -Force | Out-Null
New-Item -ItemType Directory -Path $startMenuDirectory -Force | Out-Null
Copy-Item -LiteralPath $sourceIcon -Destination $installedIcon -Force

$legacyShortcuts = @(
    (Join-Path $desktopDirectory 'OGoperation.url'),
    (Join-Path $startMenuDirectory 'OGoperation.url')
)
foreach ($legacyShortcut in $legacyShortcuts) {
    if (Test-Path -LiteralPath $legacyShortcut -PathType Leaf) {
        Remove-Item -LiteralPath $legacyShortcut -Force
    }
}

$windowsShell = New-Object -ComObject WScript.Shell
foreach ($shortcutPath in @($desktopShortcut, $startMenuShortcut)) {
    $shortcut = $windowsShell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = Join-Path $env:WINDIR 'explorer.exe'
    $shortcut.Arguments = $operationUri.AbsoluteUri
    $shortcut.WorkingDirectory = $installDirectory
    $shortcut.IconLocation = "$installedIcon,0"
    $shortcut.Description = 'Open OGoperation in the default browser'
    $shortcut.Save()
    if (-not (Test-Path -LiteralPath $shortcutPath -PathType Leaf)) {
        throw "Shortcut creation failed: $shortcutPath"
    }
}

Write-Host 'OGoperation shortcut installation completed.'
Write-Host "URL: $($operationUri.AbsoluteUri)"
Write-Host "Desktop: $desktopShortcut"
Write-Host "Start Menu: $startMenuShortcut"

