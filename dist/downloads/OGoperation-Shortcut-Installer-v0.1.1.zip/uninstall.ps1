[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

$installDirectory = Join-Path $env:LOCALAPPDATA 'OWNGROUND\OGoperation'
$installedIcon = Join-Path $installDirectory 'ogoperation.ico'
$desktopDirectory = [Environment]::GetFolderPath('Desktop')
$desktopShortcut = Join-Path $desktopDirectory 'OGoperation.lnk'
$startMenuDirectory = Join-Path ([Environment]::GetFolderPath('Programs')) 'OWNGROUND'
$startMenuShortcut = Join-Path $startMenuDirectory 'OGoperation.lnk'

foreach ($ownedFile in @(
    $desktopShortcut,
    $startMenuShortcut,
    (Join-Path $desktopDirectory 'OGoperation.url'),
    (Join-Path $startMenuDirectory 'OGoperation.url'),
    $installedIcon
)) {
    if (Test-Path -LiteralPath $ownedFile -PathType Leaf) {
        Remove-Item -LiteralPath $ownedFile -Force
    }
}

foreach ($ownedDirectory in @($installDirectory, $startMenuDirectory)) {
    if ((Test-Path -LiteralPath $ownedDirectory -PathType Container) -and
        -not (Get-ChildItem -LiteralPath $ownedDirectory -Force | Select-Object -First 1)) {
        Remove-Item -LiteralPath $ownedDirectory
    }
}

Write-Host 'OGoperation shortcut removal completed.'

